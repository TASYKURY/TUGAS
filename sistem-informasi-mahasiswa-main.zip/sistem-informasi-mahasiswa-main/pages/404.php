<div class="row mt-4 justify-content-center">
  <div class="col-12 col-md-8">
    <img src="./assets/img/404.svg" alt="" srcset="">
    <h4 class="text-center mt-4">Halaman yang anda dicari tidak ditemukan atau sudah dihapus.</h4>
  </div>
  <div class="col-12 text-center mt-4">
    <a href="/" class="d-inline btn btn-primary">KEMBALI KE BERANDA</a>
  </div>
</div>